
/**
 * RemoteExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */

package com.hunterjames.axis2.ws.messageditor.client;

public class RemoteExceptionException extends java.lang.Exception{
    
    private com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.RemoteExceptionE faultMessage;

    
        public RemoteExceptionException() {
            super("RemoteExceptionException");
        }

        public RemoteExceptionException(java.lang.String s) {
           super(s);
        }

        public RemoteExceptionException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public RemoteExceptionException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.RemoteExceptionE msg){
       faultMessage = msg;
    }
    
    public com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.RemoteExceptionE getFaultMessage(){
       return faultMessage;
    }
}
    