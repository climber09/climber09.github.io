

/**
 * MessageEditorServiceTest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
package com.hunterjames.axis2.ws.messageditor.client;

import com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetCategoryNamesResponse;
import com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessageKeysByCategoryResponse;

/*
 *  MessageEditorServiceTest Junit test case
 */
public class MessageEditorServiceTest extends junit.framework.TestCase
{
	public void testMessageEditorService() throws java.lang.Exception
	{
		String[] categories = getCategoryNames();

		for(int i = 0; i < categories.length; i++){
			System.out.println("\n[ " + categories[i] + " ]\n");

			String[] messageKeys = getMessageKeysByCategory(categories[i]);
			for(int j = 0; j < messageKeys.length; j++){
				System.out.print(messageKeys[j] + " => ");
				System.out.println( getMessage(messageKeys[j]) );
			}
		}
	}
     
    /**
     * Auto generated test method
     */
    public String getMessage(String key) throws java.lang.Exception
    {

    	com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub stub =
            new com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub();
    		//the default implementation should point to the right endpoint

        com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessage getMessageArg =
            (com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessage)
            getTestObject(com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessage.class);
       
       getMessageArg.setArgs0(key);
       MessageEditorServiceStub.GetMessageResponse response = stub.getMessage(getMessageArg);
       assertNotNull(response);
       String msg = response.get_return();
       assertNotNull(msg);
       return msg;
                    
    }

    public String[] getCategoryNames() throws java.lang.Exception
    {
        com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub stub =
            new com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub();
        	//the default implementation should point to the right endpoint

        GetCategoryNamesResponse response = stub.getCategoryNames();
        assertNotNull(response);
        return response.get_return();
    }
        

    public String[] getMessageKeysByCategory(String category) throws java.lang.Exception
    {
    	com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub stub =
            new com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub();//the default implementation should point to the right endpoint

    	com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessageKeysByCategory getMessageKeysByCategoryArg =
    		(com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessageKeysByCategory)getTestObject(com.hunterjames.axis2.ws.messageditor.client.MessageEditorServiceStub.GetMessageKeysByCategory.class);

   		getMessageKeysByCategoryArg.setArgs0(category);
   		GetMessageKeysByCategoryResponse response = stub.getMessageKeysByCategory(getMessageKeysByCategoryArg);
        assertNotNull(response);
        return response.get_return();
    }
        

    //Create an ADBBean and provide it as the test object
    public org.apache.axis2.databinding.ADBBean getTestObject(java.lang.Class type) throws java.lang.Exception{
       return (org.apache.axis2.databinding.ADBBean) type.newInstance();
    }

}
    